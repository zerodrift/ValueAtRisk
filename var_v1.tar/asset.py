from pandas.io.data import DataReader, DataFrame, read_csv
import datetime
from numpy import log, exp


class Asset(object):

    def __init__(self, name):
        self.asset_name = name

    def historical_returns(self):
        return log(self.raw_prices() / self.raw_prices().shift(1))

    def historical_simulated_prices(self):
        return self.price_today() * exp(self.historical_returns())

    def price_today(self):
        return self.raw_prices()[-1]

    def raw_prices(self):
        return DataReader(self.asset_name, "yahoo",
            datetime.date(2006, 01, 01), datetime.date(2013, 12, 31))['Adj Close'].asfreq('B').fillna(method='pad')


