import numpy as np
from pandas.io.data import DataFrame
from pandas import concat

class Portfolio(object):
    positions = []
    weights = []

    def __init__(self, **kwargs):
        self.positions = kwargs.get('insts')  # expects a variable set of arguments each is an instrument
        self.weights = np.array(map(lambda x: [x.notional], self.positions))

    def variance(self):
        try:
            # weights_array = self.weights * self.weights.transpose()
            post = np.dot(self.cov(), self.weights) # post-multiplying by weights.  see Jorion pp. 260
            return np.dot(self.weights.transpose(), post) #pre-multiplying per Jorion pp. 260.

        except Exception as e:
            raise e

    def pnl(self):
        try:
            return reduce(lambda x, y: x+y, [ins.pnl(ins.asset().historical_simulated_prices())
                                             for ins in self.positions])
        except Exception as e:
            raise e

    def std(self):
        return np.sqrt(self.variance())

    def std_deviations(self):
        return self.asset_returns_table().std()

    def asset_returns_table(self):
        try:
            return concat(map(lambda x: DataFrame({x.asset_name: x.asset().historical_returns()}),
                              self.positions), axis=1)
        except Exception as e:
            raise e

    def asset_prices_table(self):
        try:
            return concat(map(lambda x: DataFrame({x.asset_name: x.asset().historical_simulated_prices()}),
                              self.positions), axis=1)
        except Exception as e:
            raise e

    def corr(self):
        return self.asset_returns_table().corr()

    def cov(self):
        return self.asset_returns_table().cov()
