import sys
import numpy as np
import scipy.stats as sp
from forward import Forward
from portfolio import Portfolio


class Var(object):
    """
    base Value at Risk class.  provides fields to hold confidence level, time interval and the portfolio
    on which VaR will be computed.
    """
    # var confidence level .e.g, 99% confident loss will not exceed $X over the next interval
    confidence = 0
    interval = 0  # one day interval
    portfolio = None

    def __init__(self, portfolio=Portfolio(insts=[Forward(asset_name="IBM", notional=1.),
                                                  Forward(asset_name="T", notional=1.),
                                                  Forward(asset_name="C", notional=1.)]),
                 confidence=0.99, interval=1.):

        self.confidence = confidence
        self.interval = interval
        self.portfolio = portfolio

    def value_at_risk(self):
        return self.computed_var()

    def computed_var(self):
        return 0.


class HistoricalVar(Var):
    """
    sub-classed from VaR.  This provides an additional method that computes the historical_var for a given
    portfolio.
    """
    def computed_var(self):
        return self.historical_var()

    def historical_var(self):
        return self.portfolio.pnl().quantile(self.confidence)




class DeltaNormalVar(Var):
    """
    THis provides the analytical var calculation based on delta only under a Gaussian
    assumption for underlying data distribution.
    """

    def computed_var(self):
        return self.delta_normal_var()

    def delta_normal_var(self):
        return (sp.norm.ppf(self.confidence) * self.portfolio.std() * 100. * np.sqrt(self.interval))[0][0]


class MonteCarloVar(Var):
    pass


######
def main(argv):
    portfolio = Portfolio(insts=[Forward(asset_name="IBM", notional=1.),
                                                  Forward(asset_name="T", notional=1.),
                                                  Forward(asset_name="C", notional=1.)])

    historical_var_example = HistoricalVar(portfolio)
    delta_normal_var_example = DeltaNormalVar(portfolio)
    print "Positions: " + str([p.asset_name for p in portfolio.positions])
    print "Historical VaR : " + str(historical_var_example.value_at_risk())
    print "Delta-Normal VaR : " + str(delta_normal_var_example.value_at_risk())




if __name__ == "__main__":
    main(sys.argv)
