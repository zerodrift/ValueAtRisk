from asset import Asset


class Forward(object):
    notional = 1.
    fixed_rate = 0.
    expiry_years = 1.
    asset_name = None

    def asset(self):
        return Asset(self.asset_name)

    def __init__(self, asset_name="IBM", notional=1., fixed_rate=0., expiry_years=1.):
        self.notional = notional
        self.fixed_rate = fixed_rate  # for payoff : price - fixed_rate.  sign is positive.  a negative sign is additive
        self.expiry_years = expiry_years
        self.asset_name = asset_name

    def pv(self):
        return self.notional * (self.asset().price_today() - self.fixed_rate)  # undiscounted intrinsic value

    def pnl(self, price):
        return self.notional * (price - self.fixed_rate) - self.pv()

    def delta(self):
        return self.notional